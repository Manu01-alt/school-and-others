#ifndef MYLIB_H_INCLUDED
#define MYLIB_H_INCLUDED
// Declaration of the global variable for the question index
int indice;
// Main functions of the program
void aggiungi_domanda();
void somministra_questionario();
void cancella_domanda();

#endif // MYLIB_H_INCLUDED
