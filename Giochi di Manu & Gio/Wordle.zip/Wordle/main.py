# Wordle Game using Pygame - By Folloni Giorgia and Gizzi Manuel
# ----------------------------------------------------------------------------------------
import pygame
import random
from words import fourLetters, fiveLetters, sixLetters, sevenLetters, trueFiveLetters, trueFourLetters, trueSevenLetters, trueSixLetters
# Initialize Pygame
pygame.init() 

# ---------------------------------------------------------Function to handle game mode
def game_mode(mode):

    global word
    word = choose_word(mode) # Choose a word based on the selected mode   
    print(word)
    font = pygame.font.Font('freesansbold.ttf', 32)
    global guesses 
    guesses = []     # List to store the guesses
    working = True 

    # while loop that keeps the game mode screen active
    while working:
        screen.fill((0, 0, 51))  
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.event.clear(pygame.KEYDOWN)
                working = False
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    pygame.event.clear(pygame.KEYDOWN) 
                    working = False 
            elif event.type == pygame.MOUSEBUTTONDOWN:
                # Check surrender button click
                if handle_surrender_click(event.pos):
                    # surrender -> end this game mode
                    pygame.event.clear(pygame.KEYDOWN)
                    working = False

        # setting the background color and displaying the selected mode
        selected_text = font.render(f'Hai selezionato la modalità a {mode} lettere!', True, (255, 255, 255))
        screen.blit(selected_text, (125, 40))
        draw_square(mode)

        # Draw surrender button
        #setting the surrender button
        draw_surrender_button()

        
        # draw previous guesses
        for line, guess in enumerate(guesses):
            for i, letter in enumerate(guess):
                letter_surface = font.render(letter, True, (255, 255, 255))
                x = 300 - (mode - 4) * 27 + i * 55 + 13
                y = 100 + (line * 70) + 10
                screen.blit(letter_surface, (x, y))

        # Get input for the next line if there are guesses left
        if len(guesses) < 6:
            input_text = get_input(mode, len(guesses), guesses)
            if input_text is None:
                working = False
            elif not is_valid(input_text) or len(input_text) != mode:
                invalid_word_msg()
            else:
                guesses.append(input_text)
                if check_win():
                    win_screen()
                    working = False
                elif check_lose():
                    lose_screen()
                    working = False
        pygame.display.flip()
        
    return

#---------------------------------------------------------Function to draw squares based on the selected mode
def draw_square(mode):
    posX = 300 - (mode - 4) * 27
    posY = 100
    for _ in range(6):
        for i in range(mode): # For loop to draw the squares based on the selected mode
            pygame.draw.rect(screen, (20, 30, 90), (posX + i*55, posY, 50, 50), border_radius=10)
        posX = 300 - (mode - 4) * 27
        posY += 70

# ---------------------------------------------------------Function to get user input
def get_input(mode, line, guesses):
    
    input_text = ""
    font = pygame.font.Font('freesansbold.ttf', 32)

    #while loop that handles the user input
    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT: # If the user closes the window
                pygame.quit()
                return None
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_RETURN:
                    return input_text
                elif event.key == pygame.K_BACKSPACE: # If Backspace is pressed
                    input_text = input_text[:-1]
                else:
                    if len(input_text) < mode and event.unicode.isalpha(): # If the input length is less than the mode and the key is a letter
                        input_text += event.unicode.upper()
            elif event.type == pygame.MOUSEBUTTONDOWN:
                # If surrender button is clicked while typing, trigger lose screen and return to main menu
                if handle_surrender_click(event.pos):
                    return None
        
        # Redraw the screen 
        screen.fill((0, 0, 51))
        draw_square(mode)
        selected_text = font.render(f'Hai selezionato la modalità a {mode} lettere!', True, (255, 255, 255))
        screen.blit(selected_text, (125, 40))

        # draw previous guesses
        for line, guess in enumerate(guesses):
            draw_colored_square(mode, line, guess)
            for i, letter in enumerate(guess):
                letter_surface = font.render(letter, True, (255, 255, 255))
                x = 300 - (mode - 4) * 27 + i * 55 + 13
                y = 100 + (line * 70) + 10
                screen.blit(letter_surface, (x, y))

        # Redraw previous guesses
        for prev_line, guess in enumerate(guesses): #prev line is the index of the guess in the guesses list
            for i, letter in enumerate(guess):
                letter_surface = font.render(letter, True, (255, 255, 255))
                x = 300 - (mode - 4) * 27 + i * 55 + 13
                y = 100 + (prev_line * 70) + 10
                screen.blit(letter_surface, (x, y))
        

        # For loop to display the input letters in the squares
        for i, letter in enumerate(input_text):
            letter_surface = font.render(letter, True, (255, 255, 255))
            x = 300 - (mode - 4) * 27 + i * 55 + 13
            y = 100 + (len(guesses) * 70) + 10
            screen.blit(letter_surface, (x, y))

        # Draw surrender button while entering input
        draw_surrender_button()

        pygame.display.flip() 

# ---------------------------------------------------------Function to show invalid word message
def invalid_word_msg():
    # Show error message for invalid word
    font = pygame.font.Font('freesansbold.ttf', 32)
    error_text = font.render('Parola non valida!', True, (255, 0, 0))
    screen.blit(error_text, (255, 500))
    pygame.display.flip()
    pygame.time.delay(1000)
#---------------------------------------------------------Function to check the letters and color the squares
def control_word(input, mode):
    posX = 300 - (mode - 4) * 27
    posY = 100 + (len(guesses) * 70)
    for indice, char in enumerate(input):
        if char in word:
            pygame.draw.rect(screen, (73, 184, 126), (posX + indice*55, posY, 50, 50), border_radius=10)
            if char == word[indice]:
                pygame.draw.rect(screen, (255, 209, 102), (posX + indice*55, posY, 50, 50), border_radius=10)
    else:
        pygame.draw.rect(screen, (58, 58, 60), (posX + indice*55, posY, 50, 50), border_radius=10)
def get_colors_for_guess(guess, word):
    # Restituisce una lista di colori per ogni lettera della guess
    colors = [(58, 58, 60)] * len(guess)  # grigio di default
    word_letters = list(word)
    guess_letters = list(guess)

    # Prima passata: verdi (giusta posizione)
    for i in range(len(guess)):
        if guess[i] == word[i]:
            colors[i] = (73, 184, 126)  # verde
            word_letters[i] = None
            guess_letters[i] = None

    # Seconda passata: gialli (giusta lettera, posizione sbagliata)
    for i in range(len(guess)):
        if guess_letters[i] is not None and guess_letters[i] in word_letters:
            colors[i] = (255, 209, 102)  # giallo
            word_letters[word_letters.index(guess_letters[i])] = None

    return colors

# ---------------------------------------------------------Function to draw colored squares based on the guess
def draw_colored_square(mode, line, guess):
    posX = 300 - (mode - 4) * 27
    posY = 100 + (line * 70)
    colors = get_colors_for_guess(guess, word)
    for i in range(mode):
        pygame.draw.rect(screen, colors[i], (posX + i*55, posY, 50, 50), border_radius=10)

# ---------------------------------------------------------Surrender button helpers
def surrender_button_rect():
    #Return the rectangle for the surrender button in the bottom left corner
    return pygame.Rect(20, 530, 160, 50)

def draw_surrender_button():
    """Draw the surrender button on the screen."""
    rect = surrender_button_rect()
    pygame.draw.rect(screen, (150, 50, 50), rect, border_radius=10)
    pygame.draw.rect(screen, (230, 233, 247), rect, 2, border_radius=10)
    font = pygame.font.Font('freesansbold.ttf', 20)
    text = font.render('Arrenditi', True, (255, 255, 255))
    text_rect = text.get_rect(center=rect.center)
    screen.blit(text, text_rect)


def handle_surrender_click(pos):
    """If the given mouse position is inside the surrender button, show lose screen and return True."""
    if surrender_button_rect().collidepoint(pos):
        lose_screen()
        return True
    return False
# ---------------------------------------------------------Function to choose a random word based on the selected mode

def choose_word(mode):
    if mode == 4:
        return random.choice(trueFourLetters).upper()
    elif mode == 5:
        return random.choice(trueFiveLetters).upper()
    elif mode == 6:
        return random.choice(trueSixLetters).upper()
    elif mode == 7:
        return random.choice(trueSevenLetters).upper()
    else:
        return None
    
# ---------------------------------------------------------Function to check if the entered word is valid
def is_valid (word):
    if word.lower() in fourLetters or word.lower() in fiveLetters or word.lower() in sixLetters or word.lower() in sevenLetters:
        return True
    return False

# ---------------------------------------------------------Function to check win condition
def check_win():
    if guesses[-1] == word:
        return True
    return False

# ---------------------------------------------------------Function to check lose condition
def check_lose():
    if len(guesses) >= 6 and guesses[-1] != word:
        return True
    return False

# ---------------------------------------------------------Function to display win screen
def win_screen():
    screen.fill((0, 0, 51))
    font = pygame.font.Font('freesansbold.ttf', 32)
    win_text = font.render('Congratulazioni! Hai vinto!', True, (255, 255, 255))
    screen.blit(win_text, (200, 250))
    pygame.display.flip()
    pygame.time.delay(3000)  # Display the win screen for 3 seconds

# ---------------------------------------------------------Function to display lose screen
def lose_screen():
    screen.fill((0, 0, 51))
    font = pygame.font.Font('freesansbold.ttf', 32)
    lose_text = font.render(f'Game Over! Hai perso!' , True, (255, 255, 255))
    word_text = font.render(f'La parola corretta era: {word}', True, (255, 255, 255))
    screen.blit(lose_text, (200, 250))
    screen.blit(word_text, (150, 300))
    pygame.display.flip()
    pygame.time.delay(3000)  # Display the lose screen for 3 seconds

# ---------------------------------------------------------Main program loop

screen = pygame.display.set_mode((800, 600)) # Set the window size
pygame.display.set_caption("Wordle Game") # Set the window title


running = True

# Main loop
while running:
    events = pygame.event.get() # Get all events (like key presses, mouse movements, etc.)
    for event in events: 
        if event.type == pygame.QUIT: 
            running = False

    screen.fill((0, 0, 51)) #redraw the background color

    #set the font and render the welcome text
    font = pygame.font.Font('freesansbold.ttf', 32)
    text = font.render('Benvenuto in Wordle!', True, (255, 255, 255))
    screen.blit(text, (250, 60)) # Display the text on the screen
    text = font.render("Scegli una modalità:", True, (255, 255, 255))
    screen.blit(text, (225, 110))

    #if the ESC key is pressed, exit the program
    keys = pygame.key.get_pressed()
    if keys[pygame.K_ESCAPE]:
        running = False

    
    posX = 300 # X position for the rectangles
    posY = 100 # Y position for the rectangles
    font = pygame.font.Font('freesansbold.ttf', 20) # Font for the mode selection text
    
    # Draw the mode selection rectangles
    for square in range(4):
        posY += 70
        
        #                           Color       Position and size     Border radius
        pygame.draw.rect(screen, (20, 30, 90), (posX, posY, 200, 50), border_radius=10) 
        pygame.draw.rect(screen, (230, 233, 247), (posX, posY, 200, 50), 2, border_radius=10)
        
        #                            Text to display        Antialias    Color
        mode_text = font.render(f'{str(square + 4)} lettere', True, (255, 255, 255)) # Render the mode text
        screen.blit(mode_text, (posX + 50, posY + 15)) # Display the mode text on the rectangles
    
    # Check for mouse clicks on the rectangles
    for event in events:
        if event.type == pygame.MOUSEBUTTONDOWN: # If a mouse button is pressed, check if it's within any rectangle
            mouseX, mouseY = event.pos
            # For loop to check each rectangle
            for square in range(4): 
                square_top = 170 + (square * 70) # Calculate the top position of each rectangle
                square_bottom = square_top + 50 # Calculate the bottom position of each rectangle
                
                # Check if the mouse click is within the rectangle's area
                if posX <= mouseX <= posX + 200 and square_top <= mouseY <= square_bottom:
                    game_mode(square + 4) # Call the game_mode function with the selected mode
                    

    # Update the display
    pygame.display.flip()

# Quit Pygame
pygame.quit()