public interface MetodoPagamento {
    boolean paga(double importo);
}