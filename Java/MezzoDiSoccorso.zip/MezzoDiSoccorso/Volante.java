public interface Volante {
    boolean vola();
}
