public interface Trasportatore {
    boolean trasporta();
}
