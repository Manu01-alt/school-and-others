public interface Motorizzato {
   boolean hasMotore(); 
}
