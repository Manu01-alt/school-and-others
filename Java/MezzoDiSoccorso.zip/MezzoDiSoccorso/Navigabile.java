public interface Navigabile {
    boolean nuoto();
}
