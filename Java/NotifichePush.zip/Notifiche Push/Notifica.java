public interface Notifica {
    boolean invia(String messaggio);
}
